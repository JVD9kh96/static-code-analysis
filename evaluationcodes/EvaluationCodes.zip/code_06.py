def append_item(item, lst=[]):
    lst.append(item)
    return lst

if __name__ == "__main__":
    print(append_item(1))
    print(append_item(2))

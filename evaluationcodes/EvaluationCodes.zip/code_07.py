def calculate(expr: str):
    return eval(expr)

if __name__ == "__main__":
    print(calculate("2 + 2"))
